let gravity=80;
let nova=100;
let nebula=70;
let dissipate=80;
let cosmicform=90;

function displayInfo(){
    document.getElementById ("gravityInfo").innerHTML=`JS-gravity=${gravity}`;
}   document.getElementById ("novaInfo").innerHTML=`JS-nova=${novapulse}`;
    document.getElementById ("nebulaInfo").innerHTML=`JS-nebula=${nebula}`;
    document.getElementById ("dissipateInfo").innerHTML=`JS-dissipate=${dissipate}`;
    document.getElementById ("cosmicInfo").innerHTML=`JS-cosmicform=${cosmicform}`;


function gravity(){
    console.log("Gravity function");
    //affect vars (increase the gravity well explosing strength and decrease the nebula pulse charge +-10)
    gravity=gravity-10;
    nebula=nebula+10;
    //call the displayInfo
    displayInfo();
}

function nova(){
    //affect vars (increase the nova pulse charge)
    novapulse=novapulse=5;
    //call the displayInfo
    displayInfo();
}

function dissipateInfo(){
    //affect vars
    
    //call the displayInfo
}


displayInfo();